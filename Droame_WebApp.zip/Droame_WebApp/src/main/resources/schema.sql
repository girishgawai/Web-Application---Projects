create table customer (customerid integer not null, name varchar(255), city varchar(255), email varchar(255), gender varchar(255), primary key (customerid))
