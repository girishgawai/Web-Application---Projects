insert into customer (customerid, name, city, email, gender) values (101, 'Aishwarya', 'Amravati', 'aishwarya@gmail.com', 'Female')
insert into customer (customerid, name, city, email, gender) values (102 , 'Shreya', 'Pune', 'shreya@gmail.com', 'Female')
insert into customer (customerid, name, city, email, gender) values (103 , 'Stuti', 'Delhi', 'Stuti@gmail.com', 'Female')
insert into customer (customerid, name, city, email, gender) values (104 , 'Netra', 'Pune', 'Nehtra@ymail.com', 'Female')
