package com.app.services;

import java.util.List;

import org.springframework.web.servlet.ModelAndView;

import com.app.customer.Customer;

public interface AllServices {
	
	public void addCustomer(Customer obj);
	
	public ModelAndView getAllCustomers();

	public ModelAndView editData(int customerID, String name, String email, String city);

	public ModelAndView deleteCustomer(int customerID);

	public ModelAndView find(int customerID);
}
