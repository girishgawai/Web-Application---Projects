package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.app.customer.Customer;
import com.app.repository.CustomerRepository;

@Service
public class ServiceImpl implements AllServices {
	
	@Autowired
	CustomerRepository repoC;

	@Override
	public void addCustomer(Customer obj) {
		// TODO Auto-generated method stub
		repoC.save(obj);
		String name = obj.getName();
//		repoC.findByName(name).getCustomerID();
//		System.out.println(repoC.findByName(name).toString());
	}

	@Override
	public ModelAndView getAllCustomers() {
		// TODO Auto-generated method stub
		System.out.println(repoC.findAll());
		List<Customer> c = repoC.findAll();
		ModelAndView mv = new ModelAndView();
		mv.addObject("c",c);
		mv.setViewName("orderdetails");
		return mv;
		
	}

	@Override
	public ModelAndView editData(int customerID, String name, String email, String city) {
		// TODO Auto-generated method stub
		Optional<Customer> obj = repoC.findById(customerID);
		ModelAndView mv = new ModelAndView();

		if(obj.get().getName().equals(name)) {
			repoC.update(customerID, name, email, city);
			
			Customer c = repoC.findById(customerID).get();
			System.out.println(c);
			mv.addObject("c",c);
			mv.setViewName("updatedsuccess");
			return mv;
		}else {
		mv.setViewName("failupdate");
		}
		return mv;
	}

	@Override
	public ModelAndView deleteCustomer(int customerID) {
		// TODO Auto-generated method stub
		ModelAndView mv = new ModelAndView();
		if(!repoC.existsById(customerID))
		{
			mv.setViewName("faildeletecustom");
			return mv;
		}
		
		repoC.deleteById(customerID);
		mv.setViewName("deletedorder");
		return mv;
	}

	@Override
	public ModelAndView find(int customerID) {
		// TODO Auto-generated method stub
		ModelAndView mv = new ModelAndView();
		if(!repoC.existsById(customerID))
		{
			mv.setViewName("failupdate");
			return mv;
		}
		Customer c = repoC.findById(customerID).get();
		mv.addObject("c",c);
		System.out.println(c);
		mv.setViewName("particularcustomer");
		return mv;
	}
	
	
	
	

}
