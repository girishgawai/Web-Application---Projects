package com.app.customer;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(allocationSize = 5,initialValue = 105,name = "custom")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "custom")
	private int customerID;
	private String name;
	private String email;
	private String city;
	private String gender;
	
	public Customer() {
		
	}
	
	public Customer(String name, String email, String city, String gender) {
		super();
		this.name = name;
		this.email = email;
		this.city = city;
		this.gender = gender;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", name=" + name + ", email=" + email + ", city=" + city
				+ ", gender=" + gender + "]";
	}
	
	

	
}
