package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.customer.Customer;
import com.app.repository.CustomerRepository;
import com.app.services.AllServices;

@Controller
@RequestMapping("/droame")
public class AdminController {
	
	@Autowired
	CustomerRepository repoC;
	
	@Autowired
	AllServices serviceC;
	
	
	@GetMapping("/homepage")
	public String homePage()
	{
		System.out.println("HomePage");
		
		return "homepage";
	}

	@GetMapping("/checkRequest")
	public ModelAndView checkRequest()
	{
		System.out.println("checking the Request");
		return serviceC.getAllCustomers();
	}
	
	@PostMapping("/findParticular")
	public ModelAndView findParticular(@RequestParam("customerID") int customerID)
	{
		return serviceC.find(customerID);
	}

	@GetMapping("/takeOrder")
	public String takeOrder()
	{
		System.out.println("taking some new orders");
		return "addorder";
	}
	
	@GetMapping("/cancelOrder")
	public String cancelOrder()
	{
		System.out.println("cancelling the requested order");
		
		return "deletecustomer";
	}
	
	@PostMapping("/deletesuccess")
	public ModelAndView deletecustomer(@RequestParam("customerID") int customerID)
	{
		return serviceC.deleteCustomer(customerID);
	}
	
	@GetMapping("/editOrder")
	public String editOrder()
	{
		System.out.println("editing request");
		return "updateorder";
	}
	
	@PostMapping("/editedorderdata")
	public ModelAndView editOrderData(@ModelAttribute("customerID") int customerID, @ModelAttribute("name") String name, @RequestParam("email") String email, @RequestParam("city") String city)
	{
		return serviceC.editData(customerID,name,email,city);
	}
	
	@PostMapping("/newCustomer")
	@ResponseBody
	public ModelAndView newCustomer(@ModelAttribute("name") String name, @RequestParam("email") String email, @RequestParam("city") String city, @RequestParam("gender") String gender)
	{
		Customer obj = new Customer(name, email, city, gender);
		serviceC.addCustomer(obj);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject(obj);
		mv.setViewName("customeradded");	
		return mv;
	}
	
	
	
	
	
}
